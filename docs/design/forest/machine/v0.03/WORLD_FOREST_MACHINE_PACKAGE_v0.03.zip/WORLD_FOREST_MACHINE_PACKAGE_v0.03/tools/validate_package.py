#!/usr/bin/env python3
from pathlib import Path
import json, sys
from collections import Counter
try:
    import jsonschema
except ImportError:
    jsonschema = None

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
SCHEMAS = ROOT / "schemas"

def load(name):
    return json.loads((DATA/name).read_text(encoding="utf-8"))

errors=[]
warnings=[]

areas=load("areas.json")
scenes=load("scenes.json")
choices=load("choices.json")
encounters=load("encounters.json")
facts=load("world_facts.json")
events=load("world_events.json")
knowledge=load("knowledge_presentations.json")
actions=load("revelation_actions.json")
recons=load("reconstructions.json")
revisits=load("revisits.json")
syntheses=load("syntheses.json")
phases=load("synthesis_phases.json")
threads=load("threads.json")
semantic_events=load("semantic_events.json")
tbds=load("tbd_registry.json")
synthesis_contract=load("synthesis_contract.json")
elemental=load("elemental_completion_contract.json")

def unique(items,key,label):
    vals=[x[key] for x in items]
    dup=[k for k,v in Counter(vals).items() if v>1]
    if dup: errors.append(f"{label}: duplicate {key}: {dup}")

unique(areas,"id","areas")
unique(scenes,"id","scenes")
unique(choices,"id","choices")
unique(encounters,"id","encounters")
unique(facts,"id","world_facts")
unique(events,"id","world_events")
unique(knowledge,"id","knowledge")
unique(actions,"id","revelation_actions")
unique(recons,"id","reconstructions")
unique(revisits,"id","revisits")
unique(syntheses,"id","syntheses")
unique(phases,"id","phases")
unique(threads,"id","threads")
unique(semantic_events,"event_key","semantic_events")

area_ids={x["id"] for x in areas}
scene_ids={x["id"] for x in scenes}
knowledge_ids={x["id"] for x in knowledge}
synthesis_ids={x["id"] for x in syntheses}
event_ids={x["id"] for x in events}
encounter_ids={x["id"] for x in encounters}
action_ids={x["id"] for x in actions}

if len(areas)!=10: errors.append(f"expected 10 areas, got {len(areas)}")
core=[s for s in scenes if s["scene_kind"]=="core"]
if len(core)!=100: errors.append(f"expected 100 core scenes, got {len(core)}")
levels=sorted(s["level"] for s in core)
if levels!=list(range(1,101)): errors.append("core scene levels must be exactly 1..100")

for s in scenes:
    if s["area_id"] not in area_ids:
        errors.append(f"scene {s['id']} unknown area {s['area_id']}")

for c in choices:
    if c["area_id"] not in area_ids:
        errors.append(f"choice {c['id']} unknown area")
    declared = len(c["options"])
    if declared == 0:
        errors.append(f"choice {c['id']} has no options")
    if c["status"]=="OPTIONS_BOUND_WEIGHTS_TBD":
        if not any(o["status"].startswith("TBD") for o in c["options"]):
            warnings.append(f"{c['id']}: choice status says weights TBD but no option marked TBD")

for e in encounters:
    if len(e["variants"])==0:
        errors.append(f"encounter {e['id']} has no variants")
    for v in e["variants"]:
        if not v["id"].startswith(e["id"]+"_"):
            errors.append(f"variant {v['id']} parent prefix mismatch {e['id']}")

for f in facts:
    if f["area_id"] not in area_ids:
        errors.append(f"world fact {f['id']} unknown area")

for e in events:
    if e["area_id"] not in area_ids:
        errors.append(f"world event {e['id']} unknown area")

for r in recons:
    if r["presentation_id"] not in knowledge_ids:
        errors.append(f"reconstruction {r['id']} unknown presentation {r['presentation_id']}")

for r in revisits:
    if r["area_id"]!="forest/*" and r["area_id"] not in area_ids:
        errors.append(f"revisit {r['id']} unknown area {r['area_id']}")

for p in phases:
    if p["parent_id"] not in synthesis_ids:
        errors.append(f"phase {p['id']} unknown synthesis parent")
orders=sorted(p["order"] for p in phases if p["parent_id"]=="SYN_FOREST_WORLD_01")
if orders != [1,2,3,4,5]:
    errors.append(f"Forest Synthesis phases must be orders 1..5, got {orders}")

if synthesis_contract["core_scene_id"] not in scene_ids:
    errors.append("synthesis core scene missing")
if synthesis_contract["revelation_scene_id"] not in scene_ids:
    errors.append("synthesis revelation scene missing")
if synthesis_contract["revelation"]["action_id"] not in action_ids:
    errors.append("synthesis revelation action missing")
if synthesis_contract["knowledge_output"]["presentation_id"] not in knowledge_ids:
    errors.append("synthesis knowledge presentation missing")

if elemental["scene_id"] not in scene_ids:
    errors.append("elemental scene missing")
if elemental["world_event_id"] not in event_ids:
    errors.append("elemental world event missing")
if elemental["encounter_id"] not in encounter_ids:
    errors.append("elemental encounter missing")
if elemental["revelation"]["action_id"] not in action_ids:
    errors.append("elemental revelation action missing")

required_event_keys = {
    "FOREST_SYNTHESIS_PHASE_COMPLETED",
    "FOREST_SYNTHESIS_MODEL_SOLVED",
    "FOREST_KNOWLEDGE_REVELATION_READY",
    "FOREST_KNOWLEDGE_REVELATION_STARTED",
    "FOREST_KNOWLEDGE_REVELATION_COMPLETED",
    "FOREST_SYNTHESIS_COMPLETED",
}
event_keys={x["event_key"] for x in semantic_events}
missing=sorted(required_event_keys-event_keys)
if missing: errors.append(f"missing required synthesis semantic events: {missing}")

# JSON Schema validation for core dataset types.
if jsonschema is not None:
    schema_map = [
        ("areas.json","area.schema.json"),
        ("scenes.json","scene.schema.json"),
        ("choices.json","choice.schema.json"),
        ("encounters.json","encounter.schema.json"),
        ("world_facts.json","world_fact.schema.json"),
        ("knowledge_presentations.json","knowledge.schema.json"),
        ("reconstructions.json","reconstruction.schema.json"),
        ("revisits.json","revisit.schema.json"),
        ("synthesis_phases.json","synthesis_phase.schema.json"),
    ]
    for data_name, schema_name in schema_map:
        schema=json.loads((SCHEMAS/schema_name).read_text(encoding="utf-8"))
        for idx,obj in enumerate(load(data_name)):
            try:
                jsonschema.validate(obj,schema)
            except Exception as ex:
                errors.append(f"{data_name}[{idx}] schema: {ex.message if hasattr(ex,'message') else ex}")
else:
    warnings.append("jsonschema package unavailable; structural JSON Schema pass skipped")

warnings.append(f"Explicit authored TBD groups: {len(tbds)}")

report={
    "ok": not errors,
    "errors": errors,
    "warnings": warnings,
    "counts":{
        "areas":len(areas),
        "scenes":len(scenes),
        "core_scenes":len(core),
        "choices":len(choices),
        "choice_options":sum(len(c["options"]) for c in choices),
        "encounters":len(encounters),
        "encounter_variants":sum(len(e["variants"]) for e in encounters),
        "world_facts":len(facts),
        "world_events":len(events),
        "knowledge_presentations":len(knowledge),
        "revelation_actions":len(actions),
        "reconstructions":len(recons),
        "revisits":len(revisits),
        "synthesis_phases":len(phases),
        "threads":len(threads),
        "semantic_events":len(semantic_events)
    }
}
(ROOT/"validation_report.json").write_text(
    json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"
)
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(0 if report["ok"] else 1)
