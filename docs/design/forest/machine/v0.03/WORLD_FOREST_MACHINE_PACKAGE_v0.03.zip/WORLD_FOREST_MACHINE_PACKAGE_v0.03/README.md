# WORLD_FOREST_MACHINE_PACKAGE v0.01

Machine-readable working export for the first big world of Словасьянс.

## Direction of authority

```text
DESIGN MANIFESTS / REGISTRIES
        ↓
MACHINE PACKAGE
        ↓
NARRATIVE ENGINE / CONTENT LOADER
```

The package is **not allowed to invent missing authored content**.

If a source document says `TBD_*`, the package preserves that state.

## Key source versions

- `DOCUMENTATION_STANDARD` — `1.00`
- `RARITY_SYSTEM` — `1.00`
- `GAME_VISION_MANIFEST` — `0.12`
- `WORLD_CAMPAIGN_MANIFEST` — `0.21`
- `CHARACTER_WORLD_MANIFEST` — `0.14`
- `WORLD_FOREST_DOSSIER` — `0.16`
- `WORLD_FOREST_LEVEL_BLUEPRINT` — `0.13`
- `WORLD_FOREST_STATE_MAP` — `0.01`
- `WORLD_FOREST_STATE_SCHEMA` — `0.03`
- `WORLD_FOREST_CONTENT_REGISTRY` — `0.06`
- `WORLD_FOREST_ENCOUNTER_REGISTRY` — `0.02`
- `WORLD_FOREST_KNOWLEDGE_REGISTRY` — `0.03`
- `WORLD_FOREST_REVISIT_REGISTRY` — `0.01`
- `WORLD_FOREST_SYNTHESIS_REGISTRY` — `0.01`

## Main files

- `forest.bundle.json` — combined snapshot for inspection/import prototypes.
- `data/*.json` — normalized domain files.
- `schemas/*.schema.json` — structural JSON Schemas.
- `tools/validate_package.py` — cross-reference and invariant validator.
- `validation_report.json` — validator result for this build.

## Important boundaries

- `WorldFact != PlayerKnowledge`
- `Revisit != Replay`
- Encounter routing has no RNG and no hidden mascot class.
- Reconstruction is a player model, not objective history.
- Meaningful knowledge transitions use `PLAYER_INITIATED_REVELATION`.
- `MODEL_SOLVED != forest_synthesis_complete`; level 99 completes after `INTEGRATE_SYSTEM / «Увидеть целое»`.
- First-world completion after Encounter 11 requires player `RECOGNIZE_ENTITY / «Узнать»`.
- `forest_world_complete != forest_everything_known`.

## Known intentional incompleteness

See `data/tbd_registry.json`.

The most important remaining authored gaps are:
- routing-choice numeric weights where source says `TBD_WEIGHTS`;
- final encounter scripts/layouts/voice;
- exact synthesis card set and distractors;
- full Elemental dossier;
- exact Guardian future facts;
- some revisit prose rules not yet normalized into atomic runtime rules.

Those are **not validator errors**.
